#include"bibliotecas.h"

struct memoria{
    int RAM[100];
    int MemoriaInstrucoes[1000][4];
};

//A Memoria do PC esta sendo 'construida'.
MemoriaPC *montarMemoriaPC(){
    MemoriaPC *memoriaAUX = malloc(sizeof(MemoriaPC));
    
    return memoriaAUX;
}

void liberaMemoriaPC(MemoriaPC *memoriaAUX){
    free(memoriaAUX);
}

//-->COMANDOS:
//  0 -> SALVAR NA RAM
//  1 -> SOMAR
//  2 -> SUBTRAIR
// -1 -> SAIR

//Bases do Programa
void maquina(MemoriaPC *memoriaAUX){
    int cont = 0;
    int end1, end2, end3, soma, subtracao;
    //OPCODE -> Comando
    int opcode;

    do{
        opcode = memoriaAUX -> MemoriaInstrucoes[cont][0];
        switch (opcode){
        //SALVA NA MEMORIA
        case 0:
            end1 = memoriaAUX ->MemoriaInstrucoes[cont][1]; //numero
            end2 = memoriaAUX ->MemoriaInstrucoes[cont][2]; //posicao do numero
            //printf("%d\n", end1);
            memoriaAUX -> RAM[end2] = end1; //ram na posicao do numero recebe o numero
            break;

        //SOMAR
        case 1:
            end1 = memoriaAUX ->MemoriaInstrucoes[cont][1]; //posicao numero1
            end2 = memoriaAUX ->MemoriaInstrucoes[cont][2]; //posicao numero 2
            end3 = memoriaAUX ->MemoriaInstrucoes[cont][3]; // posicao resultado

            //CONTA
            soma = memoriaAUX -> RAM[end1] + memoriaAUX -> RAM[end2];
            //SALVANDO O RESULTADO
            memoriaAUX -> RAM[end3] = soma; //ram na posicao resultado recebe a soma
            break;
        
        //SUBTRACAO
        case 2:
            end1 = memoriaAUX -> MemoriaInstrucoes[cont][1];
            end2 = memoriaAUX -> MemoriaInstrucoes[cont][2];
            end3 = memoriaAUX -> MemoriaInstrucoes[cont][3];
            //CONTA
            subtracao = memoriaAUX -> RAM[end1] - memoriaAUX -> RAM[end2];
            //SALVANDO O RESULTADO
            memoriaAUX -> RAM[end3] = subtracao;
            break;
        
        }
        cont++;
    }while (opcode != -1);
}

int *funcResultado(MemoriaPC *memoriaAUX){
    return memoriaAUX->RAM;
}


//Matemática Básica
void funcSoma(MemoriaPC *memoriaAUX, int numero1, int numero2){
    //Vai salvar na memoria RAM o primeiro numero digitado
    memoriaAUX -> MemoriaInstrucoes[0][0] = 0;
    memoriaAUX -> MemoriaInstrucoes[0][1] = numero1;
    memoriaAUX -> MemoriaInstrucoes[0][2] = 0; 
    memoriaAUX -> MemoriaInstrucoes[0][3] = -1;

    //Vai salvar na memoria RAM o segundo numero digitado
    memoriaAUX -> MemoriaInstrucoes[1][0] = 0;
    memoriaAUX -> MemoriaInstrucoes[1][1] = numero2; //memoriaRAM
    memoriaAUX -> MemoriaInstrucoes[1][2] = 1;
    memoriaAUX -> MemoriaInstrucoes[1][3] = -1;

    //Vai fazer a soma
    memoriaAUX -> MemoriaInstrucoes[2][0] = 1;
    memoriaAUX -> MemoriaInstrucoes[2][1] = 0;
    memoriaAUX -> MemoriaInstrucoes[2][2] = 1;
    memoriaAUX -> MemoriaInstrucoes[2][3] = 1;

    //Para o programa
    memoriaAUX -> MemoriaInstrucoes[3][0] = -1;
    memoriaAUX -> MemoriaInstrucoes[3][1] = -1;
    memoriaAUX -> MemoriaInstrucoes[3][2] = -1;
    memoriaAUX -> MemoriaInstrucoes[3][3] = -1;

    maquina(memoriaAUX);
}

void funcSubtracao(MemoriaPC *memoriaAUX, int numero1, int numero2){
    //Vai salvar na memoria RAM o primeiro numero digitado
    memoriaAUX -> MemoriaInstrucoes[0][0] = 0;
    memoriaAUX -> MemoriaInstrucoes[0][1] = numero1;
    memoriaAUX -> MemoriaInstrucoes[0][2] = 0;
    memoriaAUX -> MemoriaInstrucoes[0][3] = -1;

    //Vai salvar na memoria RAM o segundo numero digitado
    memoriaAUX -> MemoriaInstrucoes[1][0] = 0;
    memoriaAUX -> MemoriaInstrucoes[1][1] = numero2;
    memoriaAUX -> MemoriaInstrucoes[1][2] = 1;
    memoriaAUX -> MemoriaInstrucoes[1][3] = -1;

    //Vai fazer a subtacao
    memoriaAUX -> MemoriaInstrucoes[2][0] = 2;
    memoriaAUX -> MemoriaInstrucoes[2][1] = 0;
    memoriaAUX -> MemoriaInstrucoes[2][2] = 1;
    memoriaAUX -> MemoriaInstrucoes[2][3] = 1;

    //Para o programa
    memoriaAUX -> MemoriaInstrucoes[3][0] = -1;
    memoriaAUX -> MemoriaInstrucoes[3][1] = -1;
    memoriaAUX -> MemoriaInstrucoes[3][2] = -1;
    memoriaAUX -> MemoriaInstrucoes[3][3] = -1;

    maquina(memoriaAUX);
}

void funcMultiplicacao(MemoriaPC *memoriaAUX, int multiplicando, int multiplicador){

    memoriaAUX -> MemoriaInstrucoes[0][0] = 0;   //Leva pra RAM
    memoriaAUX -> MemoriaInstrucoes[0][1]= multiplicando; //salva multiplicando na posicao 0
    memoriaAUX -> MemoriaInstrucoes[0][2] = 0; //salva multiplicando na posicao 0
    memoriaAUX -> MemoriaInstrucoes[0][3] = -1;

    memoriaAUX -> MemoriaInstrucoes[1][0] = 0;   //Leva pra RAM
    memoriaAUX -> MemoriaInstrucoes[1][1] = 0; //coloca 0 pra somar com o multiplicando
    memoriaAUX -> MemoriaInstrucoes[1][2]= 1; //0 na posicao 1
    memoriaAUX -> MemoriaInstrucoes[1][3]= -1;

    //Realiza as somas e salva o resultado na posição 1 da RAM;
    for(int i=0; i< multiplicador; i++){
        memoriaAUX -> MemoriaInstrucoes[i+2][0] = 1; //soma
        memoriaAUX -> MemoriaInstrucoes[i+2][1] = 0; //multiplicando
        memoriaAUX -> MemoriaInstrucoes[i+2][2] = 1; //com o numero que vai ficar armazenado em 1
        memoriaAUX -> MemoriaInstrucoes[i+2][3] = 1; //guarda o numero aqui
    } //soma o da posicao 0 (multiplicando) com o da posicao 1 (que no inicio é 0)

    memoriaAUX -> MemoriaInstrucoes[multiplicador+2][0] = -1;
    memoriaAUX -> MemoriaInstrucoes[multiplicador+2][1] = -1;
    memoriaAUX -> MemoriaInstrucoes[multiplicador+2][2] = -1;
    memoriaAUX -> MemoriaInstrucoes[multiplicador+2][3]= -1;

    maquina(memoriaAUX);
}

void funcDivisao(MemoriaPC *memoriaAUX, int dividendo, int divisor){
    int cont = 0;

    memoriaAUX -> MemoriaInstrucoes[0][0] = 0;   //Leva pra RAM
    memoriaAUX -> MemoriaInstrucoes[0][1] = dividendo;
    memoriaAUX -> MemoriaInstrucoes[0][2] = 0;
    memoriaAUX -> MemoriaInstrucoes[0][3] = -1;

    memoriaAUX -> MemoriaInstrucoes[1][0] = 0;   //Leva pra RAM
    memoriaAUX -> MemoriaInstrucoes[1][1] = divisor;
    memoriaAUX -> MemoriaInstrucoes[1][2] = 1;
    memoriaAUX -> MemoriaInstrucoes[1][3] = -1;

    memoriaAUX -> MemoriaInstrucoes[2][0] = -1;   //Halt
    memoriaAUX -> MemoriaInstrucoes[2][1] = -1;
    memoriaAUX -> MemoriaInstrucoes[2][2] = -1;
    memoriaAUX -> MemoriaInstrucoes[2][3] = -1;

    maquina(memoriaAUX);

    //Faz a divisão, conferindo se o dividendo é maior que o divisor
    while (memoriaAUX -> RAM[0] >= memoriaAUX -> RAM[1]){

        memoriaAUX -> MemoriaInstrucoes[0][0] = 2;   //Leva pra RAM
        memoriaAUX -> MemoriaInstrucoes[0][1] = 0;
        memoriaAUX -> MemoriaInstrucoes[0][2] = 1;
        memoriaAUX -> MemoriaInstrucoes[0][3] = 0;

        memoriaAUX -> MemoriaInstrucoes[1][0] = -1;  //Halt
        memoriaAUX -> MemoriaInstrucoes[1][1] = -1;
        memoriaAUX -> MemoriaInstrucoes[1][2] = -1;
        memoriaAUX -> MemoriaInstrucoes[1][3] = -1;

        maquina(memoriaAUX);

        //Cont -> Confere quantas foi realizada a subtração, sendo o resultado da divisão.
        cont++;
    }
    memoriaAUX -> RAM[1]=cont;
}


//Matemática
void funcPotencia(MemoriaPC *memoriaAUX, int base, int expoente){    
    if(expoente == 0)  memoriaAUX -> RAM[1] = 1;
    else if(expoente == 1) memoriaAUX -> RAM[1] = base;
    else if(expoente > 1) {
        int aux = base;
        for(int i = 0; i < (expoente - 1); i++){
            funcMultiplicacao(memoriaAUX, aux, base);
            aux = memoriaAUX -> RAM[1];
        }
    }
}

void funcSomadosQuadrados(MemoriaPC *memoriaAUX, int quadrado1, int quadrado2){
    int aux1 , aux2;

    funcPotencia(memoriaAUX, quadrado1, 2);
    aux1 = memoriaAUX -> RAM[1];
    
    funcPotencia(memoriaAUX, quadrado2, 2);
    aux2 = memoriaAUX -> RAM[1];

    funcSoma(memoriaAUX, aux1, aux2);
}

void funcDelta(MemoriaPC *memoriaAUX, int a, int b, int c){
    int auxB, aux;
    funcPotencia(memoriaAUX, b , 2);
    auxB = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, a , c);
    aux = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, aux , 4);
    aux = memoriaAUX -> RAM[1];

    funcSubtracao(memoriaAUX, auxB , aux);
}

void funcIMC(MemoriaPC *memoriaAUX, int peso, int altura){
    int aux1, aux2;

    funcMultiplicacao(memoriaAUX, peso , 1000);
    aux1 = memoriaAUX -> RAM[1];

    funcPotencia(memoriaAUX, altura , 2);
    aux2 = memoriaAUX -> RAM[1];

    funcDivisao(memoriaAUX, aux1 , aux2);
}

void funcPA(MemoriaPC *memoriaAUX, int termo, int termo1, int razao){
    int aux1;

    funcSubtracao(memoriaAUX, termo, 1);
    aux1 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, aux1, razao);
    aux1 = memoriaAUX -> RAM[1];

    funcSoma(memoriaAUX, termo1, aux1);
}

void funcSomaPA(MemoriaPC *memoriaAUX, int termofinal, int termo1, int razao){
    int aux1;

    funcPA(memoriaAUX, termofinal, termo1, razao);
    aux1 = memoriaAUX -> RAM[1];

    funcSoma(memoriaAUX, termo1, aux1);
    aux1 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, aux1, termofinal);
    aux1 = memoriaAUX -> RAM[1];

    funcDivisao(memoriaAUX, aux1, 2);
}

void funcPG(MemoriaPC *memoriaAUX, int termo, int termo1, int razao){
    int aux1;

    funcSubtracao(memoriaAUX, termo, 1);
    aux1 = memoriaAUX -> RAM[1];

    funcPotencia(memoriaAUX, razao, aux1);
    aux1 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, termo1, aux1);
}

void funcSomaPG(MemoriaPC *memoriaAUX, int termofinal, int termo1, int razao){
    int aux1, aux2;

    funcPotencia(memoriaAUX, razao, termofinal);
    aux1 = memoriaAUX -> RAM[1];

    funcSubtracao(memoriaAUX, aux1, 1);
    aux1 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, termo1, aux1);
    aux1 = memoriaAUX -> RAM[1];

    funcSubtracao(memoriaAUX, razao, 1);
    aux2 = memoriaAUX -> RAM[1];

    funcDivisao(memoriaAUX, aux1, aux2);
}

void funcFatorial(MemoriaPC *memoriaAUX, int termo){
    int aux1 = termo, aux2 = 1;
    for(int i = 0; i < termo; i++){
        funcMultiplicacao(memoriaAUX, aux2, aux1);
        aux2 = memoriaAUX -> RAM[1];
        aux1--;
    }
}

void funcRaiz(MemoriaPC *memoriaAUX, int radical, int indice){
    int aux1 = 0, aux2 = 0;

    while (aux2 != radical && aux1 <= 1000){
        aux1++;
        funcPotencia(memoriaAUX, aux1, indice);
        aux2 = memoriaAUX -> RAM[1];
    }
        if(aux1 > 1000){
            aux1 = -1;
        }

    memoriaAUX -> RAM[1] = aux1;
}

void funcFibonacci(MemoriaPC *memoriaAUX, int termofinal){
    int termo1 = 0, termo2 = 1;
    printf("%d\n",termo1);

    for(int i = 0; i < (termofinal - 2);i++){
        printf("%d\n",termo2);
        funcSoma(memoriaAUX, termo1, termo2);
        termo1 = termo2;
        termo2 = memoriaAUX -> RAM[1];
    }
}


//Area
void funcAreaTriangulo(MemoriaPC *memoriaAUX, int base, int altura){
    int aux;

    funcMultiplicacao(memoriaAUX, base, altura);
    aux = memoriaAUX -> RAM[1];

    funcDivisao(memoriaAUX, aux, 2);
}

void funcAreaQuadrado(MemoriaPC *memoriaAUX, int base){
    funcMultiplicacao(memoriaAUX, base, base);
}

void funcAreaRetangulo(MemoriaPC *memoriaAUX, int base_maior, int base_menor){
    funcMultiplicacao(memoriaAUX, base_maior, base_menor);
}


//Perimetro
void funcPerimetroTriangulo(MemoriaPC *memoriaAUX, int base, int lado1, int lado2){
    int aux;

    funcSoma(memoriaAUX, base, lado1);
    aux = memoriaAUX -> RAM[1];

    funcSoma(memoriaAUX, aux, lado2);
}

void funcPerimetroQuadrado(MemoriaPC *memoriaAUX, int base){
    funcMultiplicacao(memoriaAUX, base, 4);
}

void funcPerimetroRetangulo(MemoriaPC *memoriaAUX, int base_maior, int base_menor){
    int aux1, aux2;

    funcMultiplicacao(memoriaAUX, base_maior, 2);
    aux1 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, base_menor, 2);
    aux2 = memoriaAUX -> RAM[1];

    funcSoma(memoriaAUX, aux1, aux2);
}


//Volume
void funcVolumeParalelepipedo(MemoriaPC *memoriaAUX, int comprimento, int largura, int altura){
    int aux;
    
    funcMultiplicacao(memoriaAUX, comprimento, largura);
    aux = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, aux, altura);
}

void funcVolumePiramide(MemoriaPC *memoriaAUX, int areabase, int altura){
    int aux;
    funcMultiplicacao(memoriaAUX, areabase, altura);
    aux = memoriaAUX -> RAM[1];

    funcDivisao(memoriaAUX, aux, 3);
}

void funcVolumeCubo(MemoriaPC *memoriaAUX, int lado){
    funcPotencia(memoriaAUX, lado, 3);
}


//Fisica
void funcVelocidadeMedia(MemoriaPC *memoriaAUX, int distancia, int tempo){
    funcDivisao(memoriaAUX, distancia, tempo);
}

void funcAceleracaoMedia(MemoriaPC *memoriaAUX, int velocidade, int tempo){
    funcDivisao(memoriaAUX, velocidade, tempo);
}

void funcDistanciaPercorrida(MemoriaPC *memoriaAUX, int velocidade, int tempo){
    funcMultiplicacao(memoriaAUX, velocidade, tempo);
}

void funcForca(MemoriaPC *memoriaAUX, int massa, int aceleracao){
    funcMultiplicacao(memoriaAUX, massa, aceleracao);
}

void funcEnergia(MemoriaPC *memoriaAUX, int massa){
    funcMultiplicacao(memoriaAUX, massa, 9);
}

void funcTorricelli(MemoriaPC *memoriaAUX, int velocidade, int distancia, int aceleracao){
    int aux1, aux2;

    funcPotencia(memoriaAUX, velocidade, 2);
    aux1 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, aceleracao, distancia);
    aux2 = memoriaAUX -> RAM[1];

    funcMultiplicacao(memoriaAUX, aux2, 2);
    aux2 = memoriaAUX -> RAM[1];

    funcSoma(memoriaAUX, aux1, aux2);
}


//Conversão
void funcCelsius_Kelvin(MemoriaPC *memoriaAUX, int temperatura){
    funcSoma(memoriaAUX, temperatura, 273);
}

void funcKelvin_Celsius(MemoriaPC *memoriaAUX, int temperatura){
    funcSubtracao(memoriaAUX, temperatura, 273);
}

void funcHoraMin(MemoriaPC *memoriaAUX, int hora){
    funcMultiplicacao(memoriaAUX, hora, 60);
}

void funcMinSeg(MemoriaPC *memoriaAUX, int minuto){
    funcMultiplicacao(memoriaAUX, minuto, 60);
}

void funcMinHora(MemoriaPC *memoriaAUX, int minutos){
    funcDivisao(memoriaAUX, minutos, 60);
}

void funcSegMin(MemoriaPC *memoriaAUX, int segundos){
    funcDivisao(memoriaAUX, segundos, 60);
}

