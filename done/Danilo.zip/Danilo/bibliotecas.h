#include<stdio.h>
#include<stdlib.h>
#include<time.h>

//Contem a Memoria de Dados e a Memoria de Processamento
typedef struct memoria MemoriaPC;

//Monta a Memoria do PC
MemoriaPC *montarMemoriaPC();
void liberaMemoriaPC(MemoriaPC *memoriaAUX);

//CEREBRO DA MAQUINA -> Função que vai COMANDAR
void maquina(MemoriaPC *memoriaAUX);
//-->COMANDOS:
// 0 -> SALVAR NA RAM
// 1 -> SOMAR
// 2 -> SUBTRAIR
// 
int *funcResultado(MemoriaPC *memoriaAUX);

//Matemática Básica
void funcSoma(MemoriaPC *memoriaAUX, int numero1, int numero2);
void funcSubtracao(MemoriaPC *memoriaAUX, int numero1, int numero2);
void funcMultiplicacao(MemoriaPC *memoriaAUX, int multiplicando, int multiplicador);
void funcDivisao(MemoriaPC *memoriaAUX, int dividendo, int divisor);

//Matemática
void funcPotencia(MemoriaPC *memoriaAUX, int base, int expoente);
void funcSomadosQuadrados(MemoriaPC *memoriaAUX, int quadrado1, int quadrado2);
void funcDelta(MemoriaPC *memoriaAUX, int a, int b, int c);
void funcIMC(MemoriaPC *memoriaAUX, int peso, int altura);
void funcPA(MemoriaPC *memoriaAUX, int termo, int termo1, int razao);
void funcSomaPA(MemoriaPC *memoriaAUX, int termofinal, int termo1, int razao);
void funcPG(MemoriaPC *memoriaAUX, int termo, int termo1, int razao);
void funcSomaPG(MemoriaPC *memoriaAUX, int termofinal, int termo1, int razao);
void funcFatorial(MemoriaPC *memoriaAUX, int termo);
void funcRaiz(MemoriaPC *memoriaAUX, int radical, int indice);
void funcFibonacci(MemoriaPC *memoriaAUX, int termofinal);

//Area
void funcAreaTriangulo(MemoriaPC *memoriaAUX, int base, int altura);
void funcAreaQuadrado(MemoriaPC *memoriaAUX, int base);
void funcAreaRetangulo(MemoriaPC *memoriaAUX, int base_maior, int base_menor);

//Perimetro
void funcPerimetroTriangulo(MemoriaPC *memoriaAUX, int base, int lado1, int lado2);
void funcPerimetroQuadrado(MemoriaPC *memoriaAUX, int base);
void funcPerimetroRetangulo(MemoriaPC *memoriaAUX, int base_maior, int base_menor);

//Volume
void funcVolumeParalelepipedo(MemoriaPC *memoriaAUX, int comprimento, int largura, int altura);
void funcVolumePiramide(MemoriaPC *memoriaAUX, int areabase, int altura);
void funcVolumeCubo(MemoriaPC *memoriaAUX, int lado);

//Física
void funcVelocidadeMedia(MemoriaPC *memoriaAUX, int distancia, int tempo);
void funcAceleracaoMedia(MemoriaPC *memoriaAUX, int velocidade, int tempo);
void funcDistanciaPercorrida(MemoriaPC *memoriaAUX, int velocidade, int tempo);
void funcForca(MemoriaPC *memoriaAUX, int massa, int aceleracao);
void funcEnergia(MemoriaPC *memoriaAUX, int massa);
void funcTorricelli(MemoriaPC *memoriaAUX, int velocidade, int distancia, int aceleracao);

//Conversão
void funcCelsius_Kelvin(MemoriaPC *memoriaAUX, int numero1);
void funcKelvin_Celsius(MemoriaPC *memoriaAUX, int numero1);
void funcHoraMin(MemoriaPC *memoriaAUX, int hora);
void funcMinSeg(MemoriaPC *memoriaAUX, int minuto);
void funcMinHora(MemoriaPC *memoriaAUX, int minutos);
void funcSegMin(MemoriaPC *memoriaAUX, int segundos);
