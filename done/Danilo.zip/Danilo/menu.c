#include"menu.h"

void tabelacomandos(){
    //Imprime tabela de comandos.
    printf("\n\n"); //Deixar a matriz separada.
    //ABRE O CABEÇALHO
    //Imprime a primeira linha de TRAÇOS.
    for(int coluna = 0; coluna < 30;coluna++)
    {
        if(coluna == 0)
        {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s%s%s%s%s%s%s%s%s%s%s%s"))), TAB_TL , TAB_HOR, TAB_HOR , TAB_HOR , TAB_HOR , 
            TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_TJ);
        }
        else if(coluna == 29) printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_TR);
        else printf(BG_WHITE(BLACK(BOLD("%s"))), TAB_HOR);
    }
    printf("\n");

    //Imprime a primeira pergunta.
    for(int coluna = 0; coluna < 3;coluna++)
    {
        if(coluna == 0) printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s COMANDOS %s           FUNÇÃO           %s"))), TAB_VER , TAB_VER , TAB_VER);
    }
    printf("\n");

    //Imprime os TRAÇOS embaixo das letras.
    for(int coluna = 0; coluna < 30;coluna++)
    {

        if(coluna == 0) printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s%s%s%s%s%s%s%s%s%s%s%s"))), TAB_ML , TAB_HOR, TAB_HOR , TAB_HOR , TAB_HOR , 
        TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_MJ);

        else if(coluna == 29) printf(BG_WHITE(BLACK(BOLD("%s"))), TAB_MR);
        else printf(BG_WHITE(BLACK(BOLD("%s"))), TAB_HOR);
    }
    printf("\n");
    //Fecha o CABEÇALHO

    //Imprime as opções.       
    for(int linha = 0; linha < 35;linha++){

        if(linha == 0) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     0    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   SOMA                     "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 1){
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     1    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   SUBTRAÇÃO                "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }
        
        if(linha == 2) 
        {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     2    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   MULTIPLICAÇÃO            "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 3){
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     3    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   DIVISÃO                  "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }
        
        if(linha == 4){
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     4    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   POTÊNCIA                 "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }
        
        if(linha == 5) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     5    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   SOMA DOS QUADRADOS       "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 6) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     6    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   DELTA                    "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 7) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     7    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   IMC                      "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 8) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     8    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   PA - TERMO               "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 9) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s     9    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   SOMA DOS TERMOS - PA     "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 10) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    10    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   PG - TERMO               "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }
        
        if(linha == 11) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    11    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   SOMA DOS TERMOS - PG     "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 12) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    12    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   FATORIAL                 "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 13) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    13    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   RAIZ                     "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 14) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    14    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   FIBONACCI                "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 15) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    15    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   ÁREA DO TRIÂNGULO        "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 16) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    16    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   ÁREA DO QUADRADO         "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 17) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    17    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   ÁREA DO RETÂNGULO        "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 18) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    18    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   PERÍMETRO DO TRIÂNGULO   "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 19) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    19    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   PERÍMETRO DO QUADRADO    "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 20) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    20    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   PERÍMETRO DO RETÂNGULO   "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 21) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    21    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   VOLUME DO PARALELEPÍPEDO "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 22) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    22    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   VOLUME DA PIRÂMIDE       "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 23) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    23    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   VOLUME DO CUBO           "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 24) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    24    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   VELOCIDADE MÉDIA         "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 25) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    25    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   ACELERAÇÃO MÉDIA         "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 26) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    26    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   FORÇA                    "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 27) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    27    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   ENERGIA                  "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 28) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    28    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   TORRICELLI               "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 29) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    29    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   CELSIUS -> KELVIN        "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 30) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    30    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   KELVIN -> CELSIUS        "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 31) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    31    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   HORA -> MINUTO           "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 32) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    32    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   MINUTO -> SEGUNDO        "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 33) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    33    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   MINUTO -> HORA           "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

        if(linha == 34) {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s    34    %s"))), TAB_VER  , TAB_VER);

            printf(BG_WHITE(BLACK(BOLD("   SEGUNDO -> MINUTO        "))));
            printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_VER);
            printf("\n");
        }

    }
    //Fecha Linhas com Letras e Traços.

    for(int coluna = 0; coluna < 30;coluna++)
    {
        if(coluna == 0)
        {
            printf(BG_WHITE(BLACK(BOLD("\t\t\t\t%s%s%s%s%s%s%s%s%s%s%s%s"))), TAB_BL , TAB_HOR, TAB_HOR , TAB_HOR , TAB_HOR , 
            TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_HOR , TAB_BJ);
        }
        else if(coluna == 29) printf(BG_WHITE(BLACK(BOLD("%s"))),TAB_BR);
        else printf(BG_WHITE(BLACK(BOLD("%s"))), TAB_HOR);
    }
    printf("\n\n");
    //Fecha o CABEÇALHO
           
}