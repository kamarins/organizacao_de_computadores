#include"bibliotecas.h"
#include"menu.h"

int main(){
    int comando, numero1, numero2, numero3;
    int cont = 0;
    MemoriaPC *memoriaAUX;
    memoriaAUX = montarMemoriaPC();
    int *auxiliar;

    tabelacomandos();

    do
    {
        if(cont == 5){
            tabelacomandos();
            cont = 0;
        } 
        
        printf("--Digite o comando: ");
        scanf("%d", &comando);

        

        switch (comando){
        case 0:
            printf("Digito os números que deseja somar: ");
            scanf("%d %d", &numero1 , &numero2);
            funcSoma(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O resultado da soma é: %d.\n\n", auxiliar[1]);
            break;

        case 1:
            printf("Digito os números que deseja subtrair: ");
            scanf("%d %d", &numero1 , &numero2);
            funcSubtracao(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O resultado da subtração é: %d.\n\n", auxiliar[1]);
            break;

        case 2:
            printf("Digito os números que deseja multiplicar: ");
            scanf("%d %d", &numero1 , &numero2);
            funcMultiplicacao(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O resultado da multiplicação é: %d.\n\n", auxiliar[1]);
            break;

        case 3:
            printf("Digito os números que deseja dividir: ");
            scanf("%d %d", &numero1 , &numero2);
            funcDivisao(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O resultado da divisão é: %d.\n\n", auxiliar[1]);
            break;

        case 4:
            printf("Digite a base e a potência: ");
            scanf("%d %d", &numero1 , &numero2);
            funcPotencia(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O resultado da potência é: %d.\n\n", auxiliar[1]);
            break;
        
        case 5:
            printf("Digite a os numeros que desejam somar nos quadrados: ");
            scanf("%d %d", &numero1 , &numero2);
            funcSomadosQuadrados(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O resultado da soma dos quadrados é: %d.\n\n", auxiliar[1]);
            break;

        case 6:
            printf("Digite o valor de a, b e c: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcDelta(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("O valor de Delta é: %d.\n\n", auxiliar[1]);
            break;

        case 7:
            printf("Digite o valor do peso(kg) e da altura(cm): ");
            scanf("%d %d", &numero1, &numero2);
            funcIMC(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O valor do IMC é: %d.\n\n", auxiliar[1]);
            break;

        case 8:
            printf("Digite a posição do termo que quer encontrar, o primeiro termo e a razão: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcPA(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("O valor da posição é: %d.\n\n", auxiliar[1]);
            break;
        
        case 9:
            printf("Digite a posição final, o primeiro termo e a razão: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcSomaPA(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("A soma dos %d primeiros termos é: %d.\n\n", numero1, auxiliar[1]);
            break;

        case 10:
            printf("Digite a posição do termo que quer encontrar, o primeiro termo e a razão: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcPG(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("O valor da posição é: %d.\n\n", auxiliar[1]);
            break;

        case 11:
            printf("Digite a posição final, o primeiro termo e a razão: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcSomaPG(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("A soma dos %d primeiros termos é: %d.\n\n", numero1, auxiliar[1]);
            break;
        
        case 12:
            printf("Digite o valor do fatorial: ");
            scanf("%d", &numero1);
            funcFatorial(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("O Fatorial de %d é: %d.\n\n", numero1, auxiliar[1]);
            break;

        case 13:
            printf("Digite o radical(termo) e o indice(quadrada, cubo ...): ");
            scanf("%d %d", &numero1 , &numero2);
            funcRaiz(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            
            if(auxiliar[1] == -1){
                printf("Não é possível calcular\n\n");
            }
            else{
                printf("O resultado da raiz é: %d.\n\n", auxiliar[1]);
            }
            break;
        
        case 14:
            printf("Digite o termo que quer descobrir da sequência: ");
            scanf("%d", &numero1);
            funcFibonacci(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("-> O termo %d é: %d.\n\n",numero1, auxiliar[1]);
            break;

        case 15:
            printf("Digite a altura e a base do triângulo: ");
            scanf("%d %d", &numero1 , &numero2);
            funcAreaTriangulo(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("A área da base triângulo: %d.\n\n", auxiliar[1]);
            break;

        case 16:
            printf("Digite a base do quadrado: ");
            scanf("%d", &numero1);
            funcAreaQuadrado(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("A área da base do quadrado: %d.\n\n", auxiliar[1]);
            break;

        case 17:
            printf("Digite a base maior e base menor: ");
            scanf("%d %d", &numero1, &numero2);
            funcAreaRetangulo(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("A área da base do retângulo: %d.\n\n", auxiliar[1]);
            break;

        case 18:
            printf("Digite a base do triângulo e os 2 lados: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcPerimetroTriangulo(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("A área da base do retângulo: %d.\n\n", auxiliar[1]);
            break;

        case 19:
            printf("Digite o lado do quadrado: ");
            scanf("%d", &numero1);
            funcPerimetroQuadrado(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("A área da base do retângulo: %d.\n\n", auxiliar[1]);
            break;

        case 20:
            printf("Digite a base maior e base menor: ");
            scanf("%d %d", &numero1, &numero2);
            funcPerimetroRetangulo(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("A área da base do retângulo: %d.\n\n", auxiliar[1]);
            break;

        case 21:
            printf("Digite o comprimento, largura e altura do paralelepípedo: ");
            scanf("%d %d %d", &numero1, &numero2, &numero3);
            funcVolumeParalelepipedo(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("O volume do paralelepípedo: %d.\n\n", auxiliar[1]);
            break;

        case 22:
            printf("Digite a área da base e altura da pirâmide: ");
            scanf("%d %d", &numero1, &numero2);
            funcVolumePiramide(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O volume da pirâmide é: %d.\n\n", auxiliar[1]);
            break;

        case 23:
            printf("Digite o lado do cubo: ");
            scanf("%d", &numero1);
            funcVolumeCubo(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("O Volume do cubo é: %d.\n\n", auxiliar[1]);
            break;

        case 24:
            printf("Digite a distância em metros e o tempo em segundos: ");
            scanf("%d %d", &numero1 , &numero2);
            funcVelocidadeMedia(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("A velocidade média é: %d m/s.\n\n", auxiliar[1]);
            break;

        case 25:
            printf("Digite a vecocidade em metros/segundos e tempo em segundos : ");
            scanf("%d %d", &numero1 , &numero2);
            funcAceleracaoMedia(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("A aceleração média é: %d m/s².\n\n", auxiliar[1]);
            break;

        case 26:
            printf("Digite o valor da massa e da aceleração: ");
            scanf("%d %d", &numero1, &numero2);
            funcForca(memoriaAUX, numero1, numero2);
            auxiliar = funcResultado(memoriaAUX);
            printf("O valor da força é: %d Newtons.\n\n", auxiliar[1]);
            break;

        case 27:
            printf("Digite o valor da massa: ");
            scanf("%d", &numero1);
            funcEnergia(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("O valor da Energia é: %d x 10^9 Joules.\n\n", auxiliar[1]);
            break;

        case 28:
            printf("Digite a velocidade, a distancia e a aceleração: ");
            scanf("%d %d %d", &numero1 , &numero2, &numero3);
            funcTorricelli(memoriaAUX, numero1, numero2, numero3);
            auxiliar = funcResultado(memoriaAUX);
            printf("V² = %d.\n\n", auxiliar[1]);
            break;

        case 29:
            printf("Digite a temperatura em Celsius: ");
            scanf("%d", &numero1);
            funcCelsius_Kelvin(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("A temperatura é: %d Kelvin.\n\n", auxiliar[1]);
            break;

        case 30:
            printf("Digite a temperatura em Kelvin: ");
            scanf("%d", &numero1);
            funcKelvin_Celsius(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("A temperatura é: %d graus Celsius.\n\n", auxiliar[1]);
            break;

         case 31:
            printf("Digite as horas: ");
            scanf("%d", &numero1);
            funcHoraMin(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("%d horas são %d minutos.\n\n", numero1, auxiliar[1]);
            break;

        case 32:
            printf("Digite os minutos: ");
            scanf("%d", &numero1);
            funcMinSeg(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("%d minutos são %d segundos.\n\n", numero1, auxiliar[1]);
            break;

        case 33:
            printf("Digite os minutos: ");
            scanf("%d", &numero1);
            funcMinHora(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("%d minutos são/é %d hora(s).\n\n", numero1, auxiliar[1]);
            break;

        case 34:
            printf("Digite os segundos: ");
            scanf("%d", &numero1);
            funcSegMin(memoriaAUX, numero1);
            auxiliar = funcResultado(memoriaAUX);
            printf("%d segundos são/é %d minuto(s).\n\n", numero1, auxiliar[1]);
            break;
        
        }
        cont++;
    } while (comando != -1);

    liberaMemoriaPC(memoriaAUX);
    return 0;
}