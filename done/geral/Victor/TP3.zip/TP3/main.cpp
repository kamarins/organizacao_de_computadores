#include "memoria.hpp"

int main(){
	int opcao;
	
	time_t t;
	srand((unsigned) time(&t));

	//geraInstrucao();
	Instrucao** inst = alocaInstrucao(TAM_INST_GERADOR);
	lerInstrucao(inst);
    criaArquivo();
	HitMiss* hitMiss = inicializarHitMiss();

	clock_t tempo;
	tempo = clock();
	double tempoInicial = (double)tempo / 1000.0;

	Memoria** ram = alocarMemoria(TAM_RAM);
	Memoria** cacheUm = alocarMemoria(TAM_C1);
	Memoria** cacheDois = alocarMemoria(TAM_C2);
	Memoria** cacheTres = alocarMemoria(TAM_C3);

	preencherRam(ram, inst);
    
    processador(inst, cacheUm, cacheDois, cacheTres, ram, hitMiss, tempoInicial);

    limpaMemoria(cacheUm, TAM_C1);
    limpaMemoria(cacheDois, TAM_C2);
    limpaMemoria(cacheTres, TAM_C3);
    
	cout << "\n \tCACHE HIT CACHE 1: " << getHitOne(hitMiss) << endl;
	cout << "\tCACHE MISS CACHE 1: " << getMissOne(hitMiss) << endl;
	cout << "\tCACHE HIT CACHE 2: " << getHitTwo(hitMiss) << endl;
	cout << "\tCACHE MISS CACHE 2: " << getMissTwo(hitMiss) << endl;
	cout << "\tCACHE HIT CACHE 3: " << getHitThree(hitMiss) << endl;
	cout << "\tCACHE MISS CACHE 3: " << getMissThree(hitMiss) << endl;
	cout << "\tTOTAL DE MISS: " << getMissOne(hitMiss) + getMissTwo(hitMiss) + getMissThree(hitMiss) << endl;
    cout << "\tTOTAL DE HIT: " << (100.0 * (double)(getHitOne(hitMiss) + getHitTwo(hitMiss) + getHitThree(hitMiss))) 
	/ (double)(getHitOne(hitMiss) + getHitTwo(hitMiss) + getHitThree(hitMiss) + getHitRam(hitMiss) + getHitHD(hitMiss)) << endl;
   	//deletarInstrucao(inst);
    liberarMemoria(cacheUm, TAM_C1);
    liberarMemoria(cacheDois, TAM_C2);
    liberarMemoria(cacheTres, TAM_C3);
    liberarMemoria(ram, TAM_RAM);
	return 0;
}



