#ifndef MEMORIA_HPP
#define MEMORIA_HPP
#include "instrucao.hpp"
#define TAM_BLOCO 4
#define TAM_C1 8
#define TAM_C2 16
#define TAM_C3 32
#define TAM_RAM 500
#define TAM_HD 1200

typedef struct memoria Memoria;
typedef struct hitMiss HitMiss;

int getEndBloco(Memoria* memoria);
int getPalavra(Memoria* memoria, int indiceP);
int getAcesso(Memoria* memoria);
double getTempo(Memoria* memoria);
void setEndBloco(Memoria* memoria, int endBloco);
void setPalavra(Memoria* memoria, int indiceP, int palavra);
void setAcesso(Memoria* memoria, int nAcessos);
void setTempo(Memoria* memoria, double tempo);
int getHitOne(HitMiss* hitMiss);
int getMissOne(HitMiss* hitMiss);
int getHitTwo(HitMiss* hitMiss);
int getMissTwo(HitMiss* hitMiss);
int getHitThree(HitMiss* hitMiss);
int getMissThree(HitMiss* hitMiss);
int getCusto(hitMiss* hitMiss);
int getHitRam(HitMiss* hitMiss);
int getHitHD(HitMiss* hitMiss);
void setHitOne(hitMiss* hitMiss);
void setMissOne(HitMiss* hitMiss);
void setHitTwo(hitMiss* hitMiss);
void setMissTwo(HitMiss* hitMiss);
void setHitThree(hitMiss* hitMiss);
void setMissThree(HitMiss* hitMiss);
void setCusto(HitMiss* hitMiss, int custo);
Memoria** alocarMemoria(int tamanho);
Memoria* alocarVetor();
void criaArquivo();
void preencherRam(Memoria** ram, Instrucao** inst);
void imprimeRam(Memoria** ram);
void imprimirCache(Memoria** memoria, int tamanho);
HitMiss* inicializarHitMiss();
int buscarCache(Endereco* e, Memoria** cache, int tam_cache);
void insereCache(int valor, Memoria** memoria, Endereco* e, double tempoInicial);
void trocarCache(int endBloco, Memoria** cOrigem, int tam_cOrigem, Memoria** cDestino, int tam_cDestino, double tempoInicial);
void trocarRam(int endBloco, Memoria** ram, int tam_ram, Memoria** cDestino, int tam_cDestino, double tempoInicial);
Memoria* MMU(Memoria** c1, Memoria** c2, Memoria** c3, Memoria** ram, Endereco* e, HitMiss* hitMiss, double tempoInicial);
void trocaHD(int endBloco, Memoria** ram, int tam_ram, double tempoInicial);
void interrupcao(Instrucao** inst, Memoria** c1, Memoria** c2, Memoria** c3, Memoria** ram, HitMiss* hitMiss, double tempoInicial);
void limpaMemoria(Memoria** memoria, int tamanho);
void liberarMemoria(Memoria** memoria, int tamanho);
void liberarVetor(Memoria* memoria);
void processador(Instrucao** inst, Memoria** c1, Memoria** c2, Memoria** c3, Memoria** ram, HitMiss* hitMiss, double tempoInicial);

#endif