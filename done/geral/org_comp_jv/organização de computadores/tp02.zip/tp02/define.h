#define tamanho 100
#define opcode_somar 0
#define opcode_subtrair 1
#define opcode_levar_ram 2
#define opcode_sair -1

    //0 => opcode => somar
    //1 => opcode => subtrair
    //2 => opcode => levar pra ram
    //-1 => halt