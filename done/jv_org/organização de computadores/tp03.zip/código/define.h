#include <stdlib.h>
#include <stdio.h>

#define tamanho_hd 1000
#define quantidade_instrucoes 100
#define interrupcoes 100

#define tamanho_cache_01 8
#define tamanho_cache_02 16
#define tamanho_cache_03 32
#define tamanho_ram 64
