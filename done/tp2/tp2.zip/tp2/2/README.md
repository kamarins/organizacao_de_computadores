# BCC266-TP02
---

Esse trabalho tem como objetivo simular o funcionamento de uma memória cache. Para isso foram geradas instruções aleatórias através de um código em c++ que foram lidas e executadas pelo programa principal. É necessário compilar e executar o projeto em sua máquina:

> Windows
```bash
> gcc *.c -o main.exe -Wall
> main.exe
```

> Linux
```bash
> gcc *.c -o main -Wall
> ./main
```
