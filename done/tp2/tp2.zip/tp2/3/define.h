#include <stdlib.h>
#include <stdio.h>

#define tamanho_ram 100
#define tamanho_cache_01 8
#define tamanho_cache_02 32
#define tamanho_cache_03 128