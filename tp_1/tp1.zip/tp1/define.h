#define tamanho 1000
#define opcodeSomar 0
#define opcodeSubtrair 1
#define opcodeLevarMem 2
#define opcodeTrazerMem 3
#define opcodeSair -1

    //0 => opcode => somar
    //1 => opcode => subtrair
    //2 => opcode => levar para memoriaDados
    //3 => trazer da memoriaDados
    //-1 => halt