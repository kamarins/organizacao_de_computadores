
#include <stdio.h>

#define tamanhoRam 1000
#define tamanhoCache01 32
#define tamanhoCache02 64
#define tamanhoCache03 128
#define tamanhoInstrucao 1000
#define tamanhoPalavra 4